document.addEventListener('init', function(event) {
  if(event.target.id == 'page1') {
    pieChart1();
  } else if(event.target.id == 'page2'){
    pieChart2();
  }
});

function pieChart1() {
  var config = {
    type: 'bar',
    data: {
      labels: ["1月", "2月", "3月", "4月", "5月", "6月"],
      datasets: [{
        label: 'データセット1',
        backgroundColor: "rgba(220,0,220,0.5)",
        data: [50, 30, 60, 80, 20, 40]
      }]
    },
    options: {
      elements: {
        rectangle: {
          borderWidth: 4,
          borderColor: 'rgb(100, 0, 100)',
          borderSkipped: 'bottom'
        }
      },
      responsive: true,
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Chart.js 棒グラフ'
      },
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero:true
          }
        }]
      }
    }
  };
  var ctx = document.getElementById("aaa").getContext("2d");
  window.myBar = new Chart(ctx, config);  
}

function pieChart2() {
  var config = {
    type: 'bar',
    data: {
      labels: ["1月", "2月", "3月", "4月", "5月", "6月"],
      datasets: [{
        label: 'データセット1',
        backgroundColor: "rgba(66, 134, 244)",
        data: [50, 30, 60, 80, 20, 40]
      }]
    },
    options: {
      elements: {
        rectangle: {
          borderWidth: 4,
          borderColor: 'rgb(66, 134, 244)',
          borderSkipped: 'bottom'
        }
      },
      responsive: true,
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Chart.js 棒グラフ'
      },
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero:true
          }
        }]
      }
    }
  };
  var ctx = document.getElementById("bbb").getContext("2d");
  window.myBar = new Chart(ctx, config);  
}
